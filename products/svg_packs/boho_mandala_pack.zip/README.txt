Boho Mandala SVG Pack — 10 Designs for Cricut & Silhouette
==========================================================

Beautiful set of 10 hand-crafted boho mandala SVG designs perfect for your Cricut, Silhouette, or any cutting machine. Each design is clean, layered-ready, and commercial-use friendly. Use them for wall decor, t-shirts, tote bags, mugs, stickers, scrapbooking, and more.

✦ 10 unique high-quality SVG files
✦ Pure black silhouette designs
✦ Compatible Cricut Design Space, Silhouette Studio, Adobe Illustrator
✦ Commercial use allowed (small business)
✦ Instant digital download

FILES INCLUDED :
- design_01.svg
- design_02.svg
- design_03.svg
- design_04.svg
- design_05.svg
- design_06.svg
- design_07.svg
- design_08.svg
- design_09.svg
- design_10.svg

INSTRUCTIONS :
1. Unzip this file
2. Import the SVG files into Cricut Design Space, Silhouette Studio,
   Adobe Illustrator, or any vector software
3. Resize freely (vector format = no quality loss)
4. Cut, print, or use as you wish

LICENSE :
Small commercial use allowed (up to 500 physical items per design).
Reselling the digital files as-is is not allowed.

Thank you for your purchase!
