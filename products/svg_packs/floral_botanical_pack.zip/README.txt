Floral Botanical SVG Pack — 10 Wildflower Designs
=================================================

Elegant botanical silhouettes featuring wildflowers, branches, and herbs. Perfect for wedding stationery, wall art, kitchen decor, and feminine apparel.

✦ 10 unique floral SVG designs
✦ Vector silhouettes, scalable
✦ Cricut/Silhouette compatible
✦ Commercial use allowed
✦ Instant download

FILES INCLUDED :
- design_01.svg
- design_02.svg
- design_03.svg
- design_04.svg
- design_05.svg
- design_06.svg
- design_07.svg
- design_08.svg
- design_09.svg
- design_10.svg

INSTRUCTIONS :
1. Unzip this file
2. Import the SVG files into Cricut Design Space, Silhouette Studio,
   Adobe Illustrator, or any vector software
3. Resize freely (vector format = no quality loss)
4. Cut, print, or use as you wish

LICENSE :
Small commercial use allowed (up to 500 physical items per design).
Reselling the digital files as-is is not allowed.

Thank you for your purchase!
