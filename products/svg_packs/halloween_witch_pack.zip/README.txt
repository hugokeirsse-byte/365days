Halloween Witch SVG Pack — 10 Spooky Cute Designs
=================================================

Adorable and spooky Halloween SVG designs for crafters who love the witchy aesthetic. Perfect for Halloween shirts, tote bags, decorations, and gift tags.

✦ 10 unique Halloween SVG files
✦ Cricut, Silhouette ready
✦ Commercial use
✦ Instant download

FILES INCLUDED :
- design_01.svg
- design_02.svg
- design_03.svg
- design_04.svg
- design_05.svg
- design_06.svg
- design_07.svg
- design_08.svg
- design_09.svg
- design_10.svg

INSTRUCTIONS :
1. Unzip this file
2. Import the SVG files into Cricut Design Space, Silhouette Studio,
   Adobe Illustrator, or any vector software
3. Resize freely (vector format = no quality loss)
4. Cut, print, or use as you wish

LICENSE :
Small commercial use allowed (up to 500 physical items per design).
Reselling the digital files as-is is not allowed.

Thank you for your purchase!
