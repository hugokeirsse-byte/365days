# TPT LISTING

## Titre SEO
Christmas Multiplication Worksheets Grade 3 — Differentiated No Prep Math Practice

## Prix
$3.50

## Description
Make multiplying practice engaging with these **christmas themed** math worksheets!
Perfect for Grade 3, this no-prep pack includes 3 differentiated levels so every
student is challenged at the right pace.

**What's included:**
- 3 worksheets × 25 problems = **75 problems total**
- Support, On-Level, and Challenge levels
- Answer keys for every page
- Terms of use
- Print-ready US Letter (8.5 × 11")

**Perfect for:** morning work, homework, math centers, early finishers, sub plans.

## Tags
christmas, multiplication, grade 3, math worksheets, no prep,
differentiated, answer key, print and go, math facts, november,
common core, just print

## Standards
- Common Core Multiplication standards Grade 3
